import java.util.*;

class Node {

    String val;
    Node next;

    Node(String str) {
        this.val = str;
    }
}