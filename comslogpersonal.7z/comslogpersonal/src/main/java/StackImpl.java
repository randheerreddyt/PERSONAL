public class StackImpl {


}
