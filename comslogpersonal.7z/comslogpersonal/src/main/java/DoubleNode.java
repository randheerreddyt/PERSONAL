class DoubleNode {

    String val;
    DoubleNode next;
    DoubleNode previous;

    DoubleNode(String str) {
        this.val = str;
    }
}