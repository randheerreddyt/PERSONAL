package com.springboot.lamaspringboot;

class Node {

    String val;
    Node next;

    Node(String str) {
        this.val = str;
    }
}