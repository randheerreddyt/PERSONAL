//package com.springboot.lamaspringboot;
//
//import java.util.*;
//import org.springframework.web.bind.annotation.*;
//
//@RestController
//public class EmployeeController {
//    @RequestMapping("/")
//    public String home() {
//        return "Hello Randheer!";
//    }
//}